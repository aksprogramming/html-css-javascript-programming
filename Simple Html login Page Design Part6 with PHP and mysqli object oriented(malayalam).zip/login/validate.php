<?php

//extract($_GET);

//print_r($_POST);

$username="";
if(isset($_POST['username'])){
	$username=$_POST['username'];
}

$password="";
if(isset($_POST['password'])){
	$password=$_POST['password'];
}
 
$con=new mysqli("localhost","root","","base");


$query=$con->query("select * from user where user_name='$username' and user_password='$password'");
$count=$query->num_rows;


if($count){
	echo "Logged In";
}
else{
	header("Location: login.php?error=Password Mismatch");
}


?>